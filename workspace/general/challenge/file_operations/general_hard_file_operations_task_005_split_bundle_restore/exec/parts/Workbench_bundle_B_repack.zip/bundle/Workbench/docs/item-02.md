# 文件身份与hash

通过hash核对内容，不能只看名称。

本文件为原创虚构发行资料D02。

[返回目录](../index.html) [恢复说明](../pages/guide.html#workflow)
