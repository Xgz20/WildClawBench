# Old incomplete recovery guidance

Older release: do not treat as current bytes.
