# 版本校验

分包发行标识及完整成员。

本文件为原创虚构发行资料D06。

[返回目录](../index.html) [恢复说明](../pages/guide.html#workflow)
