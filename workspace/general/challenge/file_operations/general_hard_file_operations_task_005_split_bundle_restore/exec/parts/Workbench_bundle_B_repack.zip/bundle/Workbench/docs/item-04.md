# 笔记合并

保留原有笔记与相对附件。

本文件为原创虚构发行资料D04。

[返回目录](../index.html) [恢复说明](../pages/guide.html#workflow)
