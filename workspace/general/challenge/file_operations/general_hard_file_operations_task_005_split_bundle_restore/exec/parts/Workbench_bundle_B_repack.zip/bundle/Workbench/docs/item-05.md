# 相对资源图

资源大小写和单层根目录。

本文件为原创虚构发行资料D05。

[返回目录](../index.html) [恢复说明](../pages/guide.html#workflow)
