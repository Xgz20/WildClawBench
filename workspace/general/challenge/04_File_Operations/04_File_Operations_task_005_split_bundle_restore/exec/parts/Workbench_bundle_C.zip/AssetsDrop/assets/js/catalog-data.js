globalThis.WORKBENCH_CATALOG = [
  {
    "id": "D01",
    "title": "归档基础",
    "group": "archive",
    "summary": "独立来源路径和副本原字节。",
    "tags": [
      "copy"
    ],
    "href": "docs/item-01.md"
  },
  {
    "id": "D02",
    "title": "文件身份与hash",
    "group": "archive",
    "summary": "通过hash核对内容，不能只看名称。",
    "tags": [
      "sha256"
    ],
    "href": "docs/item-02.md"
  },
  {
    "id": "D03",
    "title": "中断恢复",
    "group": "archive",
    "summary": "恢复时再次检查hash和登记。",
    "tags": [
      "resume"
    ],
    "href": "docs/item-03.md"
  },
  {
    "id": "D04",
    "title": "笔记合并",
    "group": "notes",
    "summary": "保留原有笔记与相对附件。",
    "tags": [
      "merge"
    ],
    "href": "docs/item-04.md"
  },
  {
    "id": "D05",
    "title": "相对资源图",
    "group": "release",
    "summary": "资源大小写和单层根目录。",
    "tags": [
      "paths"
    ],
    "href": "docs/item-05.md"
  },
  {
    "id": "D06",
    "title": "版本校验",
    "group": "release",
    "summary": "分包发行标识及完整成员。",
    "tags": [
      "version"
    ],
    "href": "docs/item-06.md"
  },
  {
    "id": "D07",
    "title": "离线检索",
    "group": "notes",
    "summary": "离线本地过滤和空结果提示。",
    "tags": [
      "search"
    ],
    "href": "docs/item-07.md"
  },
  {
    "id": "D08",
    "title": "复核清单",
    "group": "notes",
    "summary": "来源、许可与最终交接。",
    "tags": [
      "check"
    ],
    "href": "docs/item-08.md"
  }
];
