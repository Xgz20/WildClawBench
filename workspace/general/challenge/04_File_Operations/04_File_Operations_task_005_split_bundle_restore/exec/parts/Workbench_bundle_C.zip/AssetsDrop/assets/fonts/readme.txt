Uses system fonts only; no external font or downloaded asset.
