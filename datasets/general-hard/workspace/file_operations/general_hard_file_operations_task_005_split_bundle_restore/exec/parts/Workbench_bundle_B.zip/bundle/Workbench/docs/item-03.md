# 中断恢复

恢复时再次检查hash和登记。

本文件为原创虚构发行资料D03。

[返回目录](../index.html) [恢复说明](../pages/guide.html#workflow)
